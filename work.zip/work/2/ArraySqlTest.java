package coboldataclasses;
/************************************************************************
 ** RES generated this class file from Data Level ARRAY-SQL-TEST in source file HELLOWORLD1.COB
 ** Generated at time 14:02:44.28 on Tuesday, 09/08/20
 ************************************************************************/

import com.res.java.lib.*;
import java.math.BigDecimal;

@SuppressWarnings("unused")
public class ArraySqlTest extends CobolBean {
	public int getSvArrMax() {
		return super.getBinaryInt(0,9);
	}
	public  void setSvArrMax(int val) {
		super.setBinaryInt(0,9,val,true);
	}
	public String getSvArrCode(int idx1) {
		return super.toString(4+30*--idx1,30);
	}
	public  void setSvArrCode(String val,int idx1) {
		super.valueOf(4+30*--idx1,30,val);
	}
	public String getSvArrDescr(int idx1) {
		return super.toString(1504+250*--idx1,250);
	}
	public  void setSvArrDescr(String val,int idx1) {
		super.valueOf(1504+250*--idx1,250,val);
	}
	public char getSvArrRowversion(int idx1) {
		return super.getChar(14004+--idx1);
	}
	public  void setSvArrRowversion(char val,int idx1) {
		super.setChar(14004+--idx1,val);
	}
	public String getSvArrRowid(int idx1) {
		return super.toString(14054+18*--idx1,18);
	}
	public  void setSvArrRowid(String val,int idx1) {
		super.valueOf(14054+18*--idx1,18,val);
	}
	public void initialize(Program p) {
		__setProgram(p);
		setSvArrMax(50);
	}
	public ArraySqlTest() {
		super(new CobolBytes(14954));
	}
	public ArraySqlTest(CobolBytes b) {//For redefines
		super(b); }
	public ArraySqlTest(CobolBytes b,int off,int len) {//For redefines
		super(b,off,len); }
	public String toString() {
		return new String(getBytes());
	}
	public void valueOf(String val) {//Bytes Vs. Chars
		valueOf(val.getBytes());
	}
	public byte[] getBytes() {
		return super.getBytes(0,14954);
	}
	public void valueOf(byte[] val) {
		super.valueOf(0,14954,val,0);
	}
}
