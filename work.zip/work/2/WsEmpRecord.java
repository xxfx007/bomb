package coboldataclasses;
/************************************************************************
 ** RES generated this class file from Data Level WS-EMP-RECORD in source file HELLOWORLD1.COB
 ** Generated at time 14:02:44.29 on Tuesday, 09/08/20
 ************************************************************************/

import com.res.java.lib.*;
import java.math.BigDecimal;

@SuppressWarnings("unused")
public class WsEmpRecord extends CobolBean {
	public String getWsName() {
		return super.toString(0,20);
	}
	public  void setWsName(String val) {
		super.valueOf(0,20,val);
	}
	public int getWsDob() {
		return super.getDisplayInt(20,8,false,false,false);
	}
	public String getWsDobAsString() {
		return super.toString(20,8);
	}
	public  void setWsDob(int val) {
		super.setDisplayInt(20,8,val,false,false,false);
	}
	public  void setWsDob(String val) {
		super.valueOf(20,8,val,true);
	}
	public BigDecimal getWsRate() {
		return super.getDisplayBigDecimal(28,6,2,false,false,false);
	}
	public String getWsRateAsString() {
		return super.toString(28,6);
	}
	public  void setWsRate(BigDecimal val) {
		super.setDisplayBigDecimal(28,6,val,2,false,false,false);
	}
	public  void setWsRate(String val) {
		super.valueOf(28,6,val,true);
	}
	public void initialize(Program p) {
		__setProgram(p);
	}
	public WsEmpRecord() {
		super(new CobolBytes(34));
	}
	public WsEmpRecord(CobolBytes b) {//For redefines
		super(b); }
	public WsEmpRecord(CobolBytes b,int off,int len) {//For redefines
		super(b,off,len); }
	public String toString() {
		return new String(getBytes());
	}
	public void valueOf(String val) {//Bytes Vs. Chars
		valueOf(val.getBytes());
	}
	public byte[] getBytes() {
		return super.getBytes(0,34);
	}
	public void valueOf(byte[] val) {
		super.valueOf(0,34,val,0);
	}
}
