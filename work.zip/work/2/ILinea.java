package coboldataclasses;
/************************************************************************
 ** RES generated this class file from Data Level I-LINEA in source file HELLOWORLD1.COB
 ** Generated at time 14:02:44.29 on Tuesday, 09/08/20
 ************************************************************************/

import com.res.java.lib.*;
import java.math.BigDecimal;

@SuppressWarnings("unused")
public class ILinea extends CobolBean {
	public void initialize(Program p) {
		__setProgram(p);
		super.valueOf(0,145,__all("ABCD",145));
	}
	public ILinea() {
		super(new CobolBytes(145));
	}
	public ILinea(CobolBytes b) {//For redefines
		super(b); }
	public ILinea(CobolBytes b,int off,int len) {//For redefines
		super(b,off,len); }
	public String toString() {
		return new String(getBytes());
	}
	public void valueOf(String val) {//Bytes Vs. Chars
		valueOf(val.getBytes());
	}
	public byte[] getBytes() {
		return super.getBytes(0,145);
	}
	public void valueOf(byte[] val) {
		super.valueOf(0,145,val,0);
	}
}
