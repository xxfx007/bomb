package cobolprogramclasses;
/************************************************************************
 ** RES generated this class file from Cobol program HELLOWORLD in source file HELLOWORLD1.COB
 ** Generated at time 14:02:44.25 on Tuesday, 09/08/20
 ************************************************************************/
import coboldataclasses.ArraySqlTest;
import coboldataclasses.ILinea;
import coboldataclasses.EmpNameDetails;
import coboldataclasses.WsEmpRecord;
import com.res.java.lib.*;
import com.res.java.lib.exceptions.*;
import java.math.BigDecimal;
import java.sql.SQLException;

@SuppressWarnings("unused")
public class Helloworld extends Program {

	public long getClId() {
		return super.getDisplayLong(0,12,false,false,false);
	}
	public String getClIdAsString() {
		return super.toString(0,12);
	}
	public  void setClId(long val) {
		super.setDisplayLong(0,12,val,false,false,false);
	}
	public  void setClId(String val) {
		super.valueOf(0,12,val,true);
	}
	private CobolFile myfile_2 = new CobolFile("D:\\DATADIR\\MYFILE2.TXT",true);
	public char getWzEndOfPopfile() {
		return super.getChar(12);
	}
	public  void setWzEndOfPopfile(char val) {
		super.setChar(12,val);
	}
	public boolean isWzEndOfPopfileNumeric() {
		return super.isNumeric(12,1);
	}
	public int getWzNumber() {
		return super.getDisplayInt(13,2,false,false,false);
	}
	public String getWzNumberAsString() {
		return super.toString(13,2);
	}
	public  void setWzNumber(int val) {
		super.setDisplayInt(13,2,val,false,false,false);
	}
	public  void setWzNumber(String val) {
		super.valueOf(13,2,val,true);
	}
	public Sqlca sqlca = new Sqlca();
	private ArraySqlTest arraySqlTest = new ArraySqlTest();
	public byte[] getArraySqlTest() {
		return arraySqlTest.getBytes();
	}
	public void setArraySqlTest(byte[] val) {
		arraySqlTest.valueOf(val);
	}
	public int getSqlReturnCode() {
		return super.getDisplayInt(15,9,true,false,false);
	}
	public String getSqlReturnCodeAsString() {
		return super.toString(15,9);
	}
	public  void setSqlReturnCode(int val) {
		super.setDisplayInt(15,9,val,true,false,false);
	}
	public  void setSqlReturnCode(String val) {
		super.valueOf(15,9,val,true);
	}
	public boolean getSqlNotFound() {
		return equals(getSqlReturnCode(),-1);
	}
	public int getGvFetchNum() {
		return super.getDisplayInt(24,8,false,false,false);
	}
	public String getGvFetchNumAsString() {
		return super.toString(24,8);
	}
	public  void setGvFetchNum(int val) {
		super.setDisplayInt(24,8,val,false,false,false);
	}
	public  void setGvFetchNum(String val) {
		super.valueOf(24,8,val,true);
	}
	private ILinea iLinea = new ILinea();
	public byte[] getILinea() {
		return iLinea.getBytes();
	}
	public void setILinea(byte[] val) {
		iLinea.valueOf(val);
	}
	public BigDecimal getWsDigit() {
		return super.getDisplayBigDecimal(32,20,5,true,false,false);
	}
	public String getWsDigitAsString() {
		return super.toString(32,20);
	}
	public  void setWsDigit(BigDecimal val) {
		super.setDisplayBigDecimal(32,20,val,5,true,false,false);
	}
	public  void setWsDigit(String val) {
		super.valueOf(32,20,val,true);
	}
	public BigDecimal getWsDigit_2() {
		return super.getDisplayBigDecimal(52,20,5,true,false,false);
	}
	public String getWsDigit_2AsString() {
		return super.toString(52,20);
	}
	public  void setWsDigit_2(BigDecimal val) {
		super.setDisplayBigDecimal(52,20,val,5,true,false,false);
	}
	public  void setWsDigit_2(String val) {
		super.valueOf(52,20,val,true);
	}
	public int getEmpIdDigit() {
		return super.getDisplayInt(72,7,false,false,false);
	}
	public String getEmpIdDigitAsString() {
		return super.toString(72,7);
	}
	public  void setEmpIdDigit(int val) {
		super.setDisplayInt(72,7,val,false,false,false);
	}
	public  void setEmpIdDigit(String val) {
		super.valueOf(72,7,val,true);
	}
	public String getEmpIdAlpha() {
		return super.toString(72,7);
	}
	public  void setEmpIdAlpha(String val) {
		super.valueOf(72,7,val);
	}
	public String getEmpName() {
		return super.toString(79,30);
	}
	public  void setEmpName(String val) {
		super.valueOf(79,30,val);
	}
	private EmpNameDetails empNameDetails = new EmpNameDetails(this,79,30);
	public byte[] getEmpNameDetails() {
		return empNameDetails.getBytes();
	}
	public void setEmpNameDetails(byte[] val) {
		empNameDetails.valueOf(val);
	}
	private WsEmpRecord wsEmpRecord = new WsEmpRecord();
	public byte[] getWsEmpRecord() {
		return wsEmpRecord.getBytes();
	}
	public void setWsEmpRecord(byte[] val) {
		wsEmpRecord.valueOf(val);
	}
	public static void main(String[] args) {
		__processCmdLineArgs(args);
		Helloworld instance_ = new Helloworld();
		instance_.execute(null); 
		System.exit(instance_.__getReturnCode());
	}
	public void execute(ProgramEnv __env) {
		initialize(this); 
		doCobolGotoStart();
	}
	Paragraph mainline=new Paragraph(this) {
	public CobolMethod run() {
		try {
			__dao().fetchCursor("SQL1");
			if(__dao().resultExists()) {
				if(__dao().getString(1)==null) wsEmpRecord.setWsDob(-1);
				else {wsEmpRecord.setWsDob(0);
					wsEmpRecord.setWsName(__dao().getString(1));}
				if(__dao().getString(2)==null) setGvFetchNum(-1);
				else {setGvFetchNum(0);
					wsEmpRecord.setWsName(__dao().getString(2));}
				if(__dao().getString(3)==null) wsEmpRecord.setWsDob(-1);
				else {wsEmpRecord.setWsDob(0);
					wsEmpRecord.setWsName(__dao().getString(3));}
				if(__dao().getString(4)==null) wsEmpRecord.setWsDob(-1);
				else {wsEmpRecord.setWsDob(0);
					wsEmpRecord.setWsName(__dao().getString(4));}
				if(__dao().getString(5)==null) wsEmpRecord.setWsDob(-1);
				else {wsEmpRecord.setWsDob(0);
					wsEmpRecord.setWsName(__dao().getString(5));}
				if(__dao().getString(6)==null) wsEmpRecord.setWsDob(-1);
				else {wsEmpRecord.setWsDob(0);
					wsEmpRecord.setWsName(__dao().getString(6));}
			}
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		wsEmpRecord.setWsName(" ");
		wsEmpRecord.setWsDob(0);
		wsEmpRecord.setWsRate(BigDecimal.ZERO);
		wsEmpRecord.setWsName(" ");
		wsEmpRecord.setWsDob(0);
		wsEmpRecord.setWsRate(BigDecimal.ZERO);
		setEmpIdDigit(1234567);
		Console.println(getString(getEmpIdAlpha(),7)+getEmpIdDigit());
		setEmpName("JOHN THOMAS PAUL ");
		Console.println("EMP-FNAME ="+getString(empNameDetails.getEmpFname(),10)+"EMP-MNAME ="+getString(empNameDetails.getEmpMname(),10)+"EMP-LNAME = "+getString(empNameDetails.getEmpLname(),10));
		setWsDigit(new BigDecimal("-2134.91021"));
		Console.println("WS-DIGIT: "+getWsDigit());
		setWsDigit_2(new BigDecimal("-9812.3478"));
		Console.println("WS-DIGIT-2: "+getWsDigit_2());
		try {
			__dao().prepareStatement("DELETE  "+
			"FROM SIMON_CLIENT WHERE CLIENT_ID = 123") ;
			__dao().executeUpdate();
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		try {
			__dao().prepareStatement("DELETE FROM SIMON_CLIENT WHERE CLIENT_ID = 123") ;
			__dao().executeUpdate();
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		Console.println(getString(getILinea(),145));
		try {
			__dao().prepareStatement("SELECT VIDEOCODE, VIDEOTITLE, VIDEOSUPPLIERCODE "+
			"from VIDEOFILE WHERE VIDEOCODE > 50") ;
			__dao().saveStatement("WSCURSOR");
			__dao().executeQuery();
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		try {
			__dao().executeStatement("WSCURSOR");
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		try {
			__dao().fetchCursor("WSCURSOR");
			for(int i1=1;i1<=arraySqlTest.getSvArrMax()&&__dao().resultExists();++i1) {
				arraySqlTest.setSvArrDescr(__dao().getString(1),i1);
				arraySqlTest.setSvArrRowversion(__dao().getChar(2),i1);
				arraySqlTest.setSvArrRowid(__dao().getString(3),i1);
			}
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		setSqlReturnCode(String.valueOf(sqlca.getSqlcode()));
		if(getSqlNotFound()) {
			sqlca.setSqlcode(Byte.parseByte("0"));
			sqlca.setSqlerrmc(" ");
			setGvFetchNum((int) (sqlca.getSqlerrd(3)) - getGvFetchNum());
		} else {
			setGvFetchNum(String.valueOf(sqlca.getSqlerrd(3)));
		}
		if((getWzNumber() > 0)==true) {
			setWzNumber(1);
		}
		if(getWzNumber() > 0==true) {
			setWzNumber(1);
		}
		setWzEndOfPopfile(__getChar(new CobolString(getWzEndOfPopfile()).leading().replace(String.valueOf(0)," ").toString()));
		try {
			__dao().prepareStatement("INSERT INTO NOTETEXT  "+
			"( "+
			"NOTETEXTID "+
			",NOTEID "+
			",USERID "+
			",TIMESTAMP "+
			",TEXT "+
			",STATUS "+
			",CATEGORY1 "+
			",CATEGORY2 "+
			",DUEDATE "+
			",ACTIONUSERID "+
			") "+
			"VALUES "+
			"( "+
			"? "+
			",? "+
			",? "+
			",? "+
			",? "+
			",? "+
			",? "+
			",? "+
			",? "+
			",? "+
			")") ;
			__dao().setChar(1,getWzEndOfPopfile());
			__dao().setChar(2,getWzEndOfPopfile());
			__dao().setChar(3,getWzEndOfPopfile());
			__dao().setChar(4,getWzEndOfPopfile());
			__dao().setChar(5,getWzEndOfPopfile());
			__dao().setChar(6,getWzEndOfPopfile());
			if(getWzNumber()<0)__dao().setChar(7,null); else __dao().setChar(7,getWzEndOfPopfile());
			if(getWzNumber()<0)__dao().setChar(8,null); else __dao().setChar(8,getWzEndOfPopfile());
			if(getWzNumber()<0)__dao().setChar(9,null); else __dao().setChar(9,getWzEndOfPopfile());
			if(getWzNumber()<0)__dao().setChar(10,null); else __dao().setChar(10,getWzEndOfPopfile());
			__dao().executeUpdate();
		} catch(SQLException se) { se.printStackTrace(); 
		} catch(Exception e) { e.printStackTrace(); System.exit(1); }
		if(!isWzEndOfPopfileNumeric()==true) {
			Console.println("Hello World2");
		} else 
		if(getWzNumber() == 0==true) {
			Console.println("Hello World");
		} else 
		if(getWzNumber() == 0==true) {
			Console.println("Hello World");
		} else 
		if(getWzNumber() == 0==true) {
			Console.println("Hello World2");
		} else 
		if(!isWzEndOfPopfileNumeric()==true) {
			Console.println("Hello World2");
		}
		else {
			Console.println("Hello World1");
		}
		return doCobolExit();
	}};
	public Helloworld() {
		super(new CobolBytes(109));
	}
	public void initialize(Program p) {
		if(__initialized) return; else __initialized=true;
		__setProgram(p);
		setWzEndOfPopfile(__getChar("Y"));
		setWzNumber(0);
		arraySqlTest.initialize(this);
		iLinea.initialize(this);
		empNameDetails.initialize(this);
		wsEmpRecord.initialize(this);
	}
}
