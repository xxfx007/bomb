package coboldataclasses;
/************************************************************************
 ** RES generated this class file from Data Level EMP-NAME-DETAILS in source file HELLOWORLD1.COB
 ** Generated at time 14:02:44.29 on Tuesday, 09/08/20
 ************************************************************************/

import com.res.java.lib.*;
import java.math.BigDecimal;

@SuppressWarnings("unused")
public class EmpNameDetails extends CobolBean {
	public String getEmpFname() {
		return super.toString(79,10);
	}
	public  void setEmpFname(String val) {
		super.valueOf(79,10,val);
	}
	public String getEmpMname() {
		return super.toString(89,10);
	}
	public  void setEmpMname(String val) {
		super.valueOf(89,10,val);
	}
	public String getEmpLname() {
		return super.toString(99,10);
	}
	public  void setEmpLname(String val) {
		super.valueOf(99,10,val);
	}
	public void initialize(Program p) {
		__setProgram(p);
	}
	public EmpNameDetails() {
		super(new CobolBytes(30));
	}
	public EmpNameDetails(CobolBytes b) {//For redefines
		super(b); }
	public EmpNameDetails(CobolBytes b,int off,int len) {//For redefines
		super(b,off,len); }
	public String toString() {
		return new String(getBytes());
	}
	public void valueOf(String val) {//Bytes Vs. Chars
		valueOf(val.getBytes());
	}
	public byte[] getBytes() {
		return super.getBytes(79,30);
	}
	public void valueOf(byte[] val) {
		super.valueOf(79,30,val,0);
	}
}
